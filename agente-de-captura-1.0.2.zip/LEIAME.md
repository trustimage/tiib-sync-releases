# Agente de Captura — instalação na estação

O Agente de Captura é o programa que fala com o scanner de mesa e entrega a
imagem à aba do navegador. Sem ele, o botão **Rescan** da tela de Análise do
Controle Qualidade aparece bloqueado, com o motivo escrito na tela.

Ele **não conhece o Tiib Control**: digitaliza e devolve os bytes pela conexão
local. Quem envia o arquivo à API é o navegador, com a sessão do operador
(ADR-0006).

## Instalar

**Pela tela de Análise** — é o caminho do operador. Na faixa amarela que
explica o bloqueio há um botão *Baixar o agente*, que entrega o pacote
`agente-de-captura.zip`. Descompacte numa pasta qualquer e, dentro dela:

```powershell
powershell -ExecutionPolicy Bypass -File .\instalar-agente.ps1
```

**Sem PowerShell**, o próprio executável do pacote se instala:

```
AgenteCaptura.exe instalar
```

Ele se copia para `%LOCALAPPDATA%`, cria o atalho de logon e sobe. Para
remover, o mesmo executável:

```
AgenteCaptura.exe desinstalar
```

Não precisa de administrador. O script copia o agente para
`%LOCALAPPDATA%\TrustImage\AgenteCaptura`, cria um atalho na pasta Inicializar
— para o agente subir a cada logon — e confere se ele respondeu na porta
`47960`.

Se a tela de Análise já estiver aberta, use **"Procurar o agente de novo"** na
faixa amarela. A aba procura o agente uma vez, ao abrir a tela; sem isso o
Rescan continuaria bloqueado até você recarregar a página.

## Remover

```powershell
powershell -ExecutionPolicy Bypass -File .\desinstalar-agente.ps1
```

Encerra o agente, tira o atalho e apaga a pasta. Não mexe no driver do
scanner, que é instalação à parte.

## Atualizar

Rode o `instalar-agente.ps1` do pacote novo. Ele encerra o agente em execução
antes de copiar — duas cópias não convivem, porque a porta é uma só.

## Fora do Windows, na máquina de quem desenvolve

Tudo acima é a estação do operador de Qualidade, que é Windows. Quem desenvolve
o Tiib Control pode subir o agente na própria máquina, com uma **Captura
Simulada** no lugar do scanner — o TWAIN não existe fora do Windows, e captura
real exigiria um adaptador SANE, que ficou como Etapa 2 (SPEC #545).

```bash
agente-captura/instalacao/instalar-agente.sh
```

Ele publica do fonte, instala em `~/.local/share/trustimage/agente-captura`,
cria o comando `agente-captura` em `~/.local/bin` e sobe o agente por
`systemd --user`. Ao fim, confere que a porta respondeu — instalar e estar
rodando são o mesmo ato, porque a aba procura o agente numa porta fixa e um
agente instalado e parado é, na tela, igual a um não instalado.

```bash
systemctl --user status agente-captura       # como está
journalctl --user -u agente-captura -f       # o que ele diz
agente-captura capturar /tmp/folha.tif       # uma passada, sem navegador
agente-captura/instalacao/desinstalar-agente.sh
```

Diferenças deliberadas em relação ao caminho Windows:

| | Estação (Windows) | Quem desenvolve (Linux) |
|---|---|---|
| Publicação | autocontida, ~88 MB | dependente de runtime, do fonte |
| Por quê | o operador não pode instalar runtime | quem desenvolve tem o SDK |
| Sobe sozinho | atalho na pasta Inicializar | `systemd --user`, com `enable --now` |
| Aparelho | TWAIN, KODAK i940 | Captura Simulada |
| Vai no pacote | sim, os `.ps1` viajam no zip | **não**, os `.sh` só existem no repositório |

**Se a porta 47960 estiver ocupada**, o instalador avisa, mostra quem a tomou e
não instala — uma unit apontada para porta ocupada ficaria reiniciando em laço.
Para subir noutra porta:

```bash
AGENTE_CAPTURA_PORTA=48960 agente-captura/instalacao/instalar-agente.sh
```

Serve para ter o agente de pé, não para o Rescan funcionar: a aba procura na
47960.

**Se você não tem o SDK do .NET**, o instalador diz isso e para. Publicar do
fonte é a decisão desse caminho; sem SDK, o caminho é o pacote da release.

## Requisitos da estação

| | |
|---|---|
| Sistema | Windows (o agente é 32 bits e roda em Windows 64 bits) |
| .NET | **não precisa** — o pacote é autocontido |
| Driver | o **TWAIN 32 bits** do scanner, instalado e funcionando (ex.: PaperStream IP para Fujitsu, KODAK SCANMATE i900 para o i940) |

O agente usa o scanner que estiver **conectado**. Se a estação tiver drivers
de vários scanners, ele testa quais abrem e usa o único conectado; com dois ou
mais conectados, nomeie o desejado em `Aparelho:Nome` no `appsettings.json`.
| Porta | `47960` livre em `127.0.0.1` |

## Por que não é um serviço do Windows

Serviço roda na **sessão 0**, que não tem área de trabalho. O TWAIN conversa
por mensagens de janela e precisa de uma sessão com desktop — a expectativa é
que a captura não funcione como serviço.

O projeto suporta ser hospedado como serviço (`UseWindowsService` continua no
código), mas isso ainda **não foi verificado na bancada**. Enquanto não for, o
caminho instalado é a sessão do operador, que é onde o scanner é usado de
qualquer forma.

Para verificar, com um PowerShell **como administrador**:

```powershell
sc.exe create "TrustimageAgenteCaptura" binPath= "%LOCALAPPDATA%\TrustImage\AgenteCaptura\AgenteCaptura.exe" start= auto
sc.exe start "TrustimageAgenteCaptura"
```

E então tentar um Rescan pela tela. Se a captura falhar por tempo esgotado com
o papel no alimentador, é a sessão 0 — e aí o serviço é abandonado de vez, com
a consequência registrada na ADR-0006.

Para desfazer:

```powershell
sc.exe stop "TrustimageAgenteCaptura"
sc.exe delete "TrustimageAgenteCaptura"
```

## Conferir na bancada, sem navegador

O próprio agente digitaliza uma folha e grava o arquivo, para separar problema
de aparelho de problema de aplicação:

```powershell
.\AgenteCaptura.exe capturar folha.tif
```

Grava o TIFF e um PNG de prévia ao lado, e escreve no console o que negociou
com o aparelho — resolução, profundidade, alimentador. É por aqui que se
descobre que o driver recusou 300 dpi, em vez de caçar fantasma na tela.

## Configuração

`appsettings.json`, seção `Aparelho`:

| Chave | Padrão | Para quê |
|---|---|---|
| `Nome` | vazio | trecho do nome do aparelho, quando há mais de um instalado |
| `Dpi` | 300 | resolução da captura |
| `BitsPorPixel` | 24 | 1 bitonal, 8 cinza, 24 colorido |
| `UsarAlimentador` | true | o i940 não tem mesa plana |
| `Duplex` | false | o Rescan substitui um Lado de Página por vez |
| `TempoLimiteSegundos` | 120 | o operador ainda está posicionando a folha |

Os padrões são os do acervo que o Controle Qualidade mostra. Mudá-los faz toda
captura nascer divergente na conferência, que é o que ensina o operador a
ignorar a lista de divergências.

Com `Nome` vazio o agente escolhe sozinho **só quando não há dúvida**: um
aparelho instalado, ele usa; dois, ele recusa e pede que você nomeie um.
Digitalizar no aparelho errado substituiria arquivo de acervo por papel de
outra mesa.
