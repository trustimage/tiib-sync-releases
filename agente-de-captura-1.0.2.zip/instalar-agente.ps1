#Requires -Version 5.1
<#
.SYNOPSIS
    Instala o Agente de Captura na estação do operador de Qualidade.

.DESCRIPTION
    Instala **para o usuário**, sem administrador: copia para %LOCALAPPDATA% e
    cria um atalho na pasta Inicializar, para o agente subir a cada logon.

    Duas decisões estão embutidas aqui, e as duas têm motivo:

    1. **Não é serviço do Windows.** Serviço roda na sessão 0, que não tem área
       de trabalho, e o TWAIN conversa por mensagens de janela — precisa de uma
       sessão com desktop. O projeto até suporta ser hospedado como serviço
       (`UseWindowsService`), mas a captura provavelmente não funcionaria ali.
       Enquanto isso não for verificado na bancada, o caminho seguro é a sessão
       do operador.

    2. **Não vai em Arquivos de Programas.** Operador de Qualidade raramente
       tem administrador, e %LOCALAPPDATA% não exige. O custo é que a instalação
       é por usuário da estação — o que, para uma estação com um operador por
       vez, é o comportamento certo.

.PARAMETER Origem
    Pasta com o AgenteCaptura.exe publicado. Por padrão, a pasta deste script.

.PARAMETER Destino
    Onde instalar. Por padrão, %LOCALAPPDATA%\TrustImage\AgenteCaptura.

.EXAMPLE
    .\instalar-agente.ps1
#>
[CmdletBinding()]
param(
    [string]$Origem,
    [string]$Destino = (Join-Path $env:LOCALAPPDATA 'TrustImage\AgenteCaptura')
)

$ErrorActionPreference = 'Stop'

# $PSScriptRoot nem sempre chega ao bloco param — depende de como o script foi
# invocado. Resolver aqui evita a falha mais boba possível numa instalação.
if (-not $Origem) {
    $Origem = if ($PSScriptRoot) { $PSScriptRoot }
              else { Split-Path -Parent $MyInvocation.MyCommand.Definition }
}

$NomeDoExecutavel = 'AgenteCaptura.exe'
$NomeDoAtalho = 'Trust Image - Agente de Captura.lnk'
$Porta = 47960

function Escrever($Texto, $Cor = 'Gray') { Write-Host $Texto -ForegroundColor $Cor }

Escrever "`nAgente de Captura - instalacao para o usuario $env:USERNAME" 'Cyan'

$executavelDeOrigem = Join-Path $Origem $NomeDoExecutavel
if (-not (Test-Path $executavelDeOrigem)) {
    throw "Nao encontrei $NomeDoExecutavel em '$Origem'. Rode este script de dentro da pasta descompactada do agente."
}

# O agente ocupa uma porta fixa: duas cópias não convivem. Derrubar a que
# estiver rodando é parte da instalação, não um efeito colateral dela.
$rodando = Get-Process -Name 'AgenteCaptura' -ErrorAction SilentlyContinue
if ($rodando) {
    Escrever "  Encerrando o agente em execucao (PID $($rodando.Id -join ', '))..."
    $rodando | Stop-Process -Force
    Start-Sleep -Seconds 2
}

Escrever "  Copiando para $Destino..."
New-Item -ItemType Directory -Path $Destino -Force | Out-Null
Copy-Item -Path (Join-Path $Origem '*') -Destination $Destino -Recurse -Force

$executavel = Join-Path $Destino $NomeDoExecutavel

$pastaInicializar = [Environment]::GetFolderPath('Startup')
$atalho = Join-Path $pastaInicializar $NomeDoAtalho
Escrever "  Criando atalho de inicializacao..."
$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($atalho)
$link.TargetPath = $executavel
$link.WorkingDirectory = $Destino
$link.Description = 'Agente de Captura do Tiib Control (Rescan)'
$link.WindowStyle = 7  # minimizado: o operador nao precisa ver a janela
$link.Save()

Escrever "  Iniciando o agente..."
Start-Process -FilePath $executavel -WorkingDirectory $Destino -WindowStyle Hidden

# A instalação só terminou quando a aba do navegador consegue achar o agente.
# Conferir a porta aqui é o que evita descobrir o problema na frente do papel.
$ligado = $false
foreach ($tentativa in 1..15) {
    Start-Sleep -Seconds 1
    if (Get-NetTCPConnection -LocalPort $Porta -State Listen -ErrorAction SilentlyContinue) {
        $ligado = $true
        break
    }
}

if ($ligado) {
    Escrever "`nPronto. O agente esta escutando em 127.0.0.1:$Porta." 'Green'
    Escrever "Ele sobe sozinho a cada logon."
    Escrever "`nNa tela de Analise do Controle Qualidade, use 'Procurar o agente de novo'"
    Escrever "se o Rescan ainda aparecer bloqueado - sem precisar recarregar a pagina."
} else {
    Escrever "`nO agente foi instalado, mas nao respondeu na porta $Porta em 15 segundos." 'Yellow'
    Escrever "Abra $executavel manualmente e veja a mensagem de erro."
    exit 1
}
