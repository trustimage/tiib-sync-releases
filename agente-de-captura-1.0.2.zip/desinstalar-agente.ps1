#Requires -Version 5.1
<#
.SYNOPSIS
    Remove o Agente de Captura da estação.

.DESCRIPTION
    Desfaz o que o instalar-agente.ps1 fez: encerra o agente, tira o atalho da
    Inicializar e apaga a pasta. Não mexe no driver do scanner, que é
    instalação à parte e serve a outros programas.

.EXAMPLE
    .\desinstalar-agente.ps1
#>
[CmdletBinding()]
param(
    [string]$Destino = (Join-Path $env:LOCALAPPDATA 'TrustImage\AgenteCaptura')
)

$ErrorActionPreference = 'Stop'

$NomeDoAtalho = 'Trust Image - Agente de Captura.lnk'

function Escrever($Texto, $Cor = 'Gray') { Write-Host $Texto -ForegroundColor $Cor }

Escrever "`nAgente de Captura - remocao" 'Cyan'

$rodando = Get-Process -Name 'AgenteCaptura' -ErrorAction SilentlyContinue
if ($rodando) {
    Escrever "  Encerrando o agente..."
    $rodando | Stop-Process -Force
    Start-Sleep -Seconds 2
}

$atalho = Join-Path ([Environment]::GetFolderPath('Startup')) $NomeDoAtalho
if (Test-Path $atalho) {
    Escrever "  Removendo o atalho de inicializacao..."
    Remove-Item $atalho -Force
}

if (Test-Path $Destino) {
    Escrever "  Apagando $Destino..."
    Remove-Item $Destino -Recurse -Force
}

Escrever "`nRemovido. O Rescan passa a aparecer bloqueado na tela de Analise." 'Green'
